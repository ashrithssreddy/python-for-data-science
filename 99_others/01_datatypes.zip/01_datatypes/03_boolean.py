x = True
type(x) == bool
print(x)

x = False
print(x)

type(x)

xx = [True, False, True]
xx

sum(xx)

sum([False, False, False])

xx[0]

type(xx)
[type(a) for a in xx]


